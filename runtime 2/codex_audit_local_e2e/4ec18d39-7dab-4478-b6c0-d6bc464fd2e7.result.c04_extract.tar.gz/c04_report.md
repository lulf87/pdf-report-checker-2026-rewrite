# C04 Evidence Extract

```json
{
  "source_file": "4ec18d39-7dab-4478-b6c0-d6bc464fd2e7.result.json",
  "c04_findings_count": 35,
  "by_code": {
    "SAMPLE_FIELD_MISSING_IN_LABEL": 28,
    "SAMPLE_COMPONENT_LABEL_NOT_FOUND": 7
  },
  "by_final_status": {
    "manual_review_required": 28,
    "refuted": 7
  },
  "by_codex_verdict": {
    "uncertain": 28,
    "refute": 7
  },
  "confirmed_count": 0,
  "confirmed_errors_count": 0,
  "manual_review_required_count": 28,
  "refuted_count": 7,
  "can_verify_label_content_count": 0,
  "has_matching_label_caption_count": 35,
  "has_matched_label_image_count": 31,
  "has_matched_label_crop_count": 0,
  "has_matched_label_ocr_count": 0,
  "has_matched_structured_fields_count": 0,
  "unused_component_count": 5
}
```

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-1-序列号批号
- component: None
- field: 序列号批号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-7", "caption_text": "№5 心脏脉冲电场消融仪-主机 中文标签样张", "subject_name": "心脏脉冲电场消融仪-主机", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-7", "caption_text": "№5 心脏脉冲电场消融仪-主机 中文标签样张", "subject_name": "心脏脉冲电场消融仪-主机", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-1"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 107 页
照片和说明
№5 心脏脉冲电场消融仪-主机 中文标签样张
№6 心脏脉冲电场消融仪-推车 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-主
机”序列号批号为“20539798”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: finding 仅能证明样品描述序列号为 20539798，并有匹配中文标签样张 caption；label_ocr/label_image 显示无 matched label OCR、无结构化字段、无裁剪图，无法核实标签本体是否缺少该字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-2-序列号批号
- component: None
- field: 序列号批号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-28", "caption_text": "№26 脉冲导管连接电缆（可选） 中文标签样张", "subject_name": "脉冲导管连接电缆（可选）", "caption_type": "label", "page_number": 119, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-28", "caption_text": "№26 脉冲导管连接电缆（可选） 中文标签样张", "subject_name": "脉冲导管连接电缆（可选）", "caption_type": "label", "page_number": 119, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "c...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 117 页
照片和说明
№25 脉冲导管连接电缆（可选）
№26 脉冲导管连接电缆（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“脉冲导管连接电缆（可
选）”序列号批号为“850778817”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中可见该部件序列号为850778817，且存在对应“中文标签样张”caption；但证据显示无匹配标签正文OCR、无结构化标签字段、无标签裁剪图，无法判断标签本体是否缺少该字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-4-序列号批号
- component: None
- field: 序列号批号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-12", "caption_text": "№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张", "subject_name": "心脏脉冲电场消融仪-ECG 主线缆", "caption_type": "label", "page_number": 111, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-12", "caption_text": "№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张", "subject_name": "心脏脉冲电场消融仪-ECG 主线缆", "caption_type": "label", "page_number": 111, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-4"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 109 页
照片和说明
№9 心脏脉冲电场消融仪-ECG 主线缆
№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪- 
ECG 主线缆”序列号批号为“2024070069”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述记录序列号批号为 2024070069，但当前证据仅有匹配的中文标签样张 caption 和页面引用；label_ocr 明确显示无完整标签正文、无裁剪图、无结构化字段，无法核验标签本体是否缺少该字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-5-序列号批号
- component: None
- field: 序列号批号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 110 页
照片和说明
№11 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）
№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-不
可透射线 ECG 导联线（可
选）”序列号批号为“2024070063”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中该部件序列号批号为2024070063，且有匹配的中文标签样张 caption；但证据显示缺少 matched_label_ocr_text、matched_label_fields 和标签裁剪图，caption 不能证明标签本体字段缺失，故无法确认或反驳该字段缺失。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-8-序列号批号
- component: None
- field: 序列号批号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 108 页
照片和说明
№7 心脏脉冲电场消融仪-触摸屏
№8 心脏脉冲电场消融仪-触摸屏 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-触
摸屏”序列号批号为“C24H006740”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中序列号批号为 C24H006740，且存在 №8 心脏脉冲电场消融仪-触摸屏中文标签样张 caption/page reference；但 matched label 无完整标签 OCR、无裁剪图、无结构化字段，无法稳定判断标签本体是否缺少该字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-9-序列号批号
- component: None
- field: 序列号批号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 113 页
照片和说明
№17 电源电缆（可选）
№18 电源电缆（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“电源电缆（可选）”序列号批号为“10822757”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述显示该部件序列号批号为10822757；caption仅能证明存在“电源电缆（可选）中文标签样张”。当前无matched_label_ocr_text、无结构化matched_label_fields且无标签裁剪图，不能稳定判断标签本体是否缺少该字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-1-生产日期
- component: None
- field: 生产日期
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-7", "caption_text": "№5 心脏脉冲电场消融仪-主机 中文标签样张", "subject_name": "心脏脉冲电场消融仪-主机", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-7", "caption_text": "№5 心脏脉冲电场消融仪-主机 中文标签样张", "subject_name": "心脏脉冲电场消融仪-主机", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-1"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 107 页
照片和说明
№5 心脏脉冲电场消融仪-主机 中文标签样张
№6 心脏脉冲电场消融仪-推车 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-主
机”生产日期为“2025-04-19”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中该部件生产日期为2025-04-19，匹配caption仅能证明第109页存在“心脏脉冲电场消融仪-主机 中文标签样张”。label_ocr显示无matched_label_ocr、无完整标签正文、无结构化字段，label_image也无crop，因此不能稳定判断标签本体是否缺少生产日期字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-2-生产日期
- component: None
- field: 生产日期
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-28", "caption_text": "№26 脉冲导管连接电缆（可选） 中文标签样张", "subject_name": "脉冲导管连接电缆（可选）", "caption_type": "label", "page_number": 119, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-28", "caption_text": "№26 脉冲导管连接电缆（可选） 中文标签样张", "subject_name": "脉冲导管连接电缆（可选）", "caption_type": "label", "page_number": 119, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "c...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 117 页
照片和说明
№25 脉冲导管连接电缆（可选）
№26 脉冲导管连接电缆（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“脉冲导管连接电缆（可
选）”生产日期为“2025-04-10”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述证据显示该部件生产日期为2025-04-10，且存在匹配的中文标签样张caption；但提供证据中没有匹配标签本体OCR、裁剪图或结构化字段，不能稳定判断标签本体是否缺少生产日期字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-4-生产日期
- component: None
- field: 生产日期
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-12", "caption_text": "№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张", "subject_name": "心脏脉冲电场消融仪-ECG 主线缆", "caption_type": "label", "page_number": 111, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-12", "caption_text": "№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张", "subject_name": "心脏脉冲电场消融仪-ECG 主线缆", "caption_type": "label", "page_number": 111, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-4"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 109 页
照片和说明
№9 心脏脉冲电场消融仪-ECG 主线缆
№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪- 
ECG 主线缆”生产日期为“2024-07-13”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中生产日期为2024-07-13；匹配到当前部件中文标签样张caption和页面引用，但无标签裁剪图、完整标签OCR文本或结构化字段，无法判断标签本体是否缺少生产日期字段。按C04证据规则应为证据不足。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-5-生产日期
- component: None
- field: 生产日期
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 110 页
照片和说明
№11 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）
№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-不
可透射线 ECG 导联线（可
选）”生产日期为“2024-10-11”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: finding 仅证明样品描述中生产日期为 2024-10-11；label_caption 证明当前部件存在中文标签样张 caption，但证据显示无 matched_label_ocr_text、无结构化标签字段、无标签 crop，不能稳定判断标签本体是否缺少生产日期字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-8-生产日期
- component: None
- field: 生产日期
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 108 页
照片和说明
№7 心脏脉冲电场消融仪-触摸屏
№8 心脏脉冲电场消融仪-触摸屏 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-触
摸屏”生产日期为“2024-10-14”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: finding 显示样品描述生产日期为 2024-10-14；label_caption 仅证明第110页存在“№8 ... 中文标签样张”caption。label_ocr/label_image 未提供匹配标签正文 OCR、结构化字段或标签裁剪图，无法判断标签本体是否缺少生产日期字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-9-生产日期
- component: None
- field: 生产日期
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 113 页
照片和说明
№17 电源电缆（可选）
№18 电源电缆（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“电源电缆（可选）”生产日期为“2017-10-15”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中的生产日期为2017-10-15，且存在“电源电缆（可选） 中文标签样张”caption；但未提供当前部件的标签本体OCR、裁剪图或结构化字段，不能稳定判断标签是否缺少生产日期字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-1-规格型号
- component: None
- field: 规格型号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-7", "caption_text": "№5 心脏脉冲电场消融仪-主机 中文标签样张", "subject_name": "心脏脉冲电场消融仪-主机", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-7", "caption_text": "№5 心脏脉冲电场消融仪-主机 中文标签样张", "subject_name": "心脏脉冲电场消融仪-主机", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-1"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 107 页
照片和说明
№5 心脏脉冲电场消融仪-主机 中文标签样张
№6 心脏脉冲电场消融仪-推车 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-主
机”规格型号为“PFA-GEN-01”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中规格型号为 PFA-GEN-01，且有匹配的中文标签样张 caption；但 label_ocr 显示无 matched_label_ocr_text、无结构化字段、无标签裁剪图，label_image 也仅有页面引用且裁剪不可用。现有证据不能验证标签本体是否缺少该字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-2-规格型号
- component: None
- field: 规格型号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-28", "caption_text": "№26 脉冲导管连接电缆（可选） 中文标签样张", "subject_name": "脉冲导管连接电缆（可选）", "caption_type": "label", "page_number": 119, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-28", "caption_text": "№26 脉冲导管连接电缆（可选） 中文标签样张", "subject_name": "脉冲导管连接电缆（可选）", "caption_type": "label", "page_number": 119, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "c...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 117 页
照片和说明
№25 脉冲导管连接电缆（可选）
№26 脉冲导管连接电缆（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“脉冲导管连接电缆（可
选）”规格型号为“A-UNI-PF-CBL”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述规格型号为 A-UNI-PF-CBL，匹配到“脉冲导管连接电缆（可选）中文标签样张”caption；但未提供 matched_label_ocr_text、matched_label_fields 或标签裁剪图，caption 只能证明样张存在，不能确认标签本体缺少规格型号字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-4-规格型号
- component: None
- field: 规格型号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-12", "caption_text": "№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张", "subject_name": "心脏脉冲电场消融仪-ECG 主线缆", "caption_type": "label", "page_number": 111, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-12", "caption_text": "№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张", "subject_name": "心脏脉冲电场消融仪-ECG 主线缆", "caption_type": "label", "page_number": 111, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-4"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 109 页
照片和说明
№9 心脏脉冲电场消融仪-ECG 主线缆
№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪- 
ECG 主线缆”规格型号为“PFA-ECG-CBL”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中规格型号为 PFA-ECG-CBL，但当前证据仅能证明第111页存在匹配的中文标签样张 caption；label_ocr/label_image 显示无 matched label OCR、无结构化标签字段、无标签裁剪图，不能稳定判断标签本体是否缺少规格型号字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-5-规格型号
- component: None
- field: 规格型号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 110 页
照片和说明
№11 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）
№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-不
可透射线 ECG 导联线（可
选）”规格型号为“PFA-ECG-RNAM”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: finding 仅显示样品描述规格型号为 PFA-ECG-RNAM，匹配标签证据为 caption 文本；label_caption 只能证明第112页存在该部件中文标签样张，不能证明标签本体字段缺失。缺少 matched_label_ocr_text、crop 或 structured fields，无法稳定确认或反驳规格型号是否在标签中。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-8-规格型号
- component: None
- field: 规格型号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 108 页
照片和说明
№7 心脏脉冲电场消融仪-触摸屏
№8 心脏脉冲电场消融仪-触摸屏 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-触
摸屏”规格型号为“PFA-GEN-TS”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中规格型号为 PFA-GEN-TS，但匹配证据只有第110页中文标签样张 caption 和页面引用；label_ocr 未提供标签本体 OCR 正文、裁剪图或结构化字段，不能稳定判断标签本体是否缺少规格型号字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-9-规格型号
- component: None
- field: 规格型号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 113 页
照片和说明
№17 电源电缆（可选）
№18 电源电缆（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“电源电缆（可选）”规格型号为“GEN-PWR-CH”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述给出规格型号 GEN-PWR-CH，但可用证据仅能确认第115页存在“电源电缆（可选）中文标签样张”caption；matched_label_ocr_text 为空、matched_label_fields 为空且无标签裁剪/完整正文，不能稳定判断标签本体是否缺少该字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-10-规格型号
- component: None
- field: 规格型号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-10"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 114 页
照片和说明
№19 等电位线缆 （3m）（可选）
№20 等电位线缆 （3m）（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“等电位线缆（3m）（可
选）”规格型号为“S100003”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述中规格型号为 S100003，但匹配证据仅能证明第116页存在对应中文标签样张 caption/page reference；label_ocr 显示无 matched label OCR、无完整标签正文、无裁剪图、无结构化字段，无法稳定判断标签本体是否缺少规格型号字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-11-规格型号
- component: None
- field: 规格型号
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 112 页
照片和说明
№15 光接收器
№16 光接收器（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“光接收器（可选）”规格型号为“S100018”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述可见光接收器（可选）规格型号为 S100018，且有对应中文标签样张 caption；但未提供 matched_label_ocr_text、matched_label_fields 或标签裁剪图，page_text 仅能证明 caption/照片页文本，不能确认标签本体缺少规格型号字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-1-部件名称
- component: None
- field: 部件名称
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-7", "caption_text": "№5 心脏脉冲电场消融仪-主机 中文标签样张", "subject_name": "心脏脉冲电场消融仪-主机", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-7", "caption_text": "№5 心脏脉冲电场消融仪-主机 中文标签样张", "subject_name": "心脏脉冲电场消融仪-主机", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-1"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 107 页
照片和说明
№5 心脏脉冲电场消融仪-主机 中文标签样张
№6 心脏脉冲电场消融仪-推车 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-主
机”部件名称为“心脏脉冲电场消融仪-主
机”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: finding 提供了样品描述中的部件名称；label_caption 和 label_image 仅能证明第109页存在匹配的中文标签样张 caption/page reference。label_ocr 明确显示无 matched label OCR、无 crop、无完整标签正文、无结构化字段，因此不能稳定确认标签本体缺少“部件名称”字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-2-部件名称
- component: None
- field: 部件名称
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-28", "caption_text": "№26 脉冲导管连接电缆（可选） 中文标签样张", "subject_name": "脉冲导管连接电缆（可选）", "caption_type": "label", "page_number": 119, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-28", "caption_text": "№26 脉冲导管连接电缆（可选） 中文标签样张", "subject_name": "脉冲导管连接电缆（可选）", "caption_type": "label", "page_number": 119, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-2"}, {"caption_id": "c...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 117 页
照片和说明
№25 脉冲导管连接电缆（可选）
№26 脉冲导管连接电缆（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“脉冲导管连接电缆（可
选）”部件名称为“脉冲导管连接电缆（可
选）”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述给出该部件名称，且存在对应中文标签样张 caption；但 matched_label_ocr_text 为空、matched_label_fields 为空且无标签裁剪/完整正文，不能稳定判断标签本体是否缺少部件名称字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-4-部件名称
- component: None
- field: 部件名称
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-12", "caption_text": "№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张", "subject_name": "心脏脉冲电场消融仪-ECG 主线缆", "caption_type": "label", "page_number": 111, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-12", "caption_text": "№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张", "subject_name": "心脏脉冲电场消融仪-ECG 主线缆", "caption_type": "label", "page_number": 111, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-4"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 109 页
照片和说明
№9 心脏脉冲电场消融仪-ECG 主线缆
№10 心脏脉冲电场消融仪-ECG 主线缆  中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪- 
ECG 主线缆”部件名称为“心脏脉冲电场消融仪- 
ECG 主线缆”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述字段存在；匹配到“中文标签样张”caption和页面引用，但label_ocr显示无匹配标签正文OCR、无结构化字段、无裁剪图，无法验证标签本体是否缺少部件名称。按C04证据不足规则应为uncertain。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-5-部件名称
- component: None
- field: 部件名称
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-5"...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 110 页
照片和说明
№11 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）
№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-不
可透射线 ECG 导联线（可
选）”部件名称为“心脏脉冲电场消融仪-不
可透射线 ECG 导联线（可
选）”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: finding evidence shows the rule candidate is based on the label OCR not recognizing the 部件名称 field; label_caption evidence shows a matching Chinese label sample caption exists, but no matched label body OCR, crop, or structured fields are available to verify whether the label itself lacks the field.

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-8-部件名称
- component: None
- field: 部件名称
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-8"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 108 页
照片和说明
№7 心脏脉冲电场消融仪-触摸屏
№8 心脏脉冲电场消融仪-触摸屏 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“心脏脉冲电场消融仪-触
摸屏”部件名称为“心脏脉冲电场消融仪-触
摸屏”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述给出部件名称，且第110页存在“№8 心脏脉冲电场消融仪-触摸屏 中文标签样张”caption；但证据仅有caption和页面引用，没有标签本体crop、matched_label_ocr_text或结构化字段，不能稳定判断标签本体是否缺少“部件名称”字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-9-部件名称
- component: None
- field: 部件名称
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-9"...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 113 页
照片和说明
№17 电源电缆（可选）
№18 电源电缆（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“电源电缆（可选）”部件名称为“电源电缆（可选）”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 样品描述给出部件名称为“电源电缆（可选）”，并存在对应中文标签样张 caption；但 matched_label_ocr_text 为空、matched_label_fields 为空且无标签裁剪/完整标签正文，证据只能证明样张存在，不能稳定判断标签本体缺少部件名称字段。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-10-部件名称
- component: None
- field: 部件名称
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-10"}]
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 114 页
照片和说明
№19 等电位线缆 （3m）（可选）
№20 等电位线缆 （3m）（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“等电位线缆（3m）（可
选）”部件名称为“等电位线缆（3m）（可
选）”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 规则初判基于中文标签 OCR 未识别字段，但证据显示仅有匹配的中文标签样张 caption 和页面引用；matched_label_ocr_text、标签裁剪图和结构化字段均缺失，无法核验标签本体是否缺少“部件名称”。

## SAMPLE_FIELD_MISSING_IN_LABEL / manual_review_required / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-11-部件名称
- component: None
- field: 部件名称
- severity: error
- codex: uncertain / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-11"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-...
- matched_label_page_text: 上
海
市
医
疗
器
械
检
验
研
究
院
检 验 报 告 照 片 页
报告编号：国医检（设）字 QW2025 第 2795 号      样品编号：QW2025-2795       共 118 页 第 112 页
照片和说明
№15 光接收器
№16 光接收器（可选） 中文标签样张
- matched_label_fields: {}
- message: 样品描述部件“光接收器（可选）”部件名称为“光接收器（可选）”，但中文标签 OCR 未识别到对应字段
- codex_reasoning: 证据仅显示第114页存在“№16 光接收器（可选） 中文标签样张”caption，但 finding/metadata 显示无 matched_label_ocr_text、无结构化 matched_label_fields、无标签裁剪图，不能核实标签本体是否缺少“部件名称”。

## SAMPLE_COMPONENT_LABEL_NOT_FOUND / refuted / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-3-label-missing
- component: None
- field: None
- severity: warn
- codex: refute / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-8", "caption_text": "№6 心脏脉冲电场消融仪-推车 中文标签样张", "subject_name": "心脏脉冲电场消融仪-推车", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-8", "caption_text": "№6 心脏脉冲电场消融仪-推车 中文标签样张", "subject_name": "心脏脉冲电场消融仪-推车", "caption_type": "label", "page_number": 109, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-3"}]
- matched_label_fields: {}
- message: 未找到与样品描述部件匹配的中文标签 OCR
- codex_reasoning: 样品描述第3行为“心脏脉冲电场消融仪-推车”且备注为“/”；证据存在匹配 caption“№6 心脏脉冲电场消融仪-推车 中文标签样张”及第109页页面引用。缺 matched_label_ocr/结构化字段只能说明标签正文无法核验，不能支持“标签未找到”。

## SAMPLE_COMPONENT_LABEL_NOT_FOUND / refuted / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-6-label-missing
- component: None
- field: None
- severity: warn
- codex: refute / high
- unused: True / 本次检测未
使用
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-6"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-6"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-6"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-6"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-6"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-6"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-6"...
- matched_label_fields: {}
- message: 未找到与样品描述部件匹配的中文标签 OCR
- codex_reasoning: finding 证据显示该样品行备注为“本次检测未使用”，按任务规则不适用标签覆盖错误；且 label_caption 证据存在中文标签样张 caption，不能确认 label-not-found。

## SAMPLE_COMPONENT_LABEL_NOT_FOUND / refuted / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-7-label-missing
- component: None
- field: None
- severity: warn
- codex: refute / high
- unused: True / 本次检测未
使用
- has_matching_caption: True
- has_label_image: False
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matching_label_caption_candidates: [{"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-7"}]
- matched_label_fields: {}
- message: 未找到与样品描述部件匹配的中文标签 OCR
- codex_reasoning: 候选为 C04 标签未找到，但 rule_context 和 page_text 均显示 sample-row-7 备注为“本次检测未使用”。按审核规则，未使用部件不适用标签覆盖错误，因此反驳该 finding。

## SAMPLE_COMPONENT_LABEL_NOT_FOUND / refuted / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-12-label-missing
- component: None
- field: None
- severity: warn
- codex: refute / high
- unused: True / 本次检测未
使用
- has_matching_caption: True
- has_label_image: False
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matching_label_caption_candidates: [{"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-12"}, {"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-12"}]
- matched_label_fields: {}
- message: 未找到与样品描述部件匹配的中文标签 OCR
- codex_reasoning: page_text 和 finding 均显示 row 12 备注为“本次检测未使用”，rule_context 也标记 is_unused_component=true；按 C04 指令该部件不适用标签覆盖错误，因此反驳该 label-not-found 候选。

## SAMPLE_COMPONENT_LABEL_NOT_FOUND / refuted / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-13-label-missing
- component: None
- field: None
- severity: warn
- codex: refute / high
- unused: True / 本次检测未
使用
- has_matching_caption: True
- has_label_image: False
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matching_label_caption_candidates: [{"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-13"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-13"}, {"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-13"}]
- matched_label_fields: {}
- message: 未找到与样品描述部件匹配的中文标签 OCR
- codex_reasoning: 样品描述第13行备注为“本次检测未使用”，按任务规则不适用中文标签覆盖错误；且仅有候选caption、无匹配标签OCR/结构化字段，不能支持label-not-found结论。

## SAMPLE_COMPONENT_LABEL_NOT_FOUND / refuted / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-14-label-missing
- component: None
- field: None
- severity: warn
- codex: refute / high
- unused: False / None
- has_matching_caption: True
- has_label_image: True
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matched_label_caption: {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}}
- matching_label_caption_candidates: [{"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-14"}, {"caption_id": "caption-10", "caption_text": "№8 心脏脉冲电场消融仪-触摸屏 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏", "caption_type": "label", "page_number": 110, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-14"}]
- matched_label_fields: {}
- message: 未找到与样品描述部件匹配的中文标签 OCR
- codex_reasoning: 样品行14备注为“/”，适用核对；但 label_caption 和 label_image 显示第117页存在“№22 触摸屏连接线缆（30m）（可选） 中文标签样张”及页面引用。虽然缺少 matched_label_ocr、结构化字段和裁剪图，不能判断标签内容完整性，但可反驳“标签未找到”。

## SAMPLE_COMPONENT_LABEL_NOT_FOUND / refuted / 4ec18d39-7dab-4478-b6c0-d6bc464fd2e7-c04-sample-row-15-label-missing
- component: None
- field: None
- severity: warn
- codex: refute / high
- unused: True / 本次检测未
使用
- has_matching_caption: True
- has_label_image: False
- has_label_crop: False
- has_label_ocr: False
- has_structured_fields: False
- can_verify_label_content: False
- matching_label_caption_candidates: [{"caption_id": "caption-14", "caption_text": "№12 心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-不可透射线 ECG 导联线（可选）", "caption_type": "label", "page_number": 112, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-15"}, {"caption_id": "caption-16", "caption_text": "№14 光纤（15m）（可选） 中文标签样张", "subject_name": "光纤（15m）（可选）", "caption_type": "label", "page_number": 113, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-15"}, {"caption_id": "caption-18", "caption_text": "№16 光接收器（可选） 中文标签样张", "subject_name": "光接收器（可选）", "caption_type": "label", "page_number": 114, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-15"}, {"caption_id": "caption-20", "caption_text": "№18 电源电缆（可选） 中文标签样张", "subject_name": "电源电缆（可选）", "caption_type": "label", "page_number": 115, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-15"}, {"caption_id": "caption-22", "caption_text": "№20 等电位线缆 （3m）（可选） 中文标签样张", "subject_name": "等电位线缆 （3m）（可选）", "caption_type": "label", "page_number": 116, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-15"}, {"caption_id": "caption-24", "caption_text": "№22 触摸屏连接线缆（30m）（可选）  中文标签样张", "subject_name": "触摸屏连接线缆（30m）（可选）", "caption_type": "label", "page_number": 117, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-row-15"}, {"caption_id": "caption-26", "caption_text": "№24 心脏脉冲电场消融仪-触摸屏电源适配器（可选） 中文标签样张", "subject_name": "心脏脉冲电场消融仪-触摸屏电源适配器（可选）", "caption_type": "label", "page_number": 118, "matched_component_ids": [], "metadata": {"is_chinese_label": true}, "component_id": "sample-...
- matched_label_fields: {}
- message: 未找到与样品描述部件匹配的中文标签 OCR
- codex_reasoning: finding 证据显示 sample-row-15 备注为“本次检测未使用”；按 C04 审核规则，该部件不适用中文标签覆盖错误，因此反驳 label-not-found 候选。
